#ifndef __DELAY_H
#define __DELAY_H 			   
#include "sys.h"
////////////////////////////////////////////////////////////////////////////////// 	 
void delay_init(void);
void Delay_ms(u16 nms);
void Delay_us(u32 nus);

#endif





























